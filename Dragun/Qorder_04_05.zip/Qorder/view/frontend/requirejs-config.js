var config = {
    paths: {
        'quickorderr': "Dragun_Qorder/js/component"
    },
    shim: {
        'quickorderr': {
            deps: ['jquery']
        }
    }
}